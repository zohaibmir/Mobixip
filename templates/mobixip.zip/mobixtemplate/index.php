  <?php defined( '_JEXEC' ) or die( 'Restricted access' );?>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml"   xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
	<head>
        <jdoc:include type="head" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/system.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/general.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/template.css" type="text/css" />
	</head>
	  </head>
  
	  <body>
  
  
		  <div class="container">
  
  
			  <div class="header">
				  <div class="header-top">
					  <div class="sitelogo" >
						  <a href="#">
							<img src="images/MobiXIP.jpg" src="Site Logo" id="logo" width="163px" height="142px" style="z-index:-1" />
						  </a>
					  </div>
  
					  <div class="menu">
						  <ul >
							  <li><a href="#">Home</a></li>
							  <li><a href="#">Products</a></li>
							  <li><a href="#">Services</a></li>
							  <li><a href="#">Career</a></li>
							  <li><a href="#">Clients</a></li>
							  <li><a href="#">Portfolio</a></li>
							  <li><a href="#">Contact Us</a></li>
						  </ul>
						  <br style="clear:left"/>
					  </div>
					  <!-- end .Top header -->
				  </div>
  
				  <div class="header-bottom">
  
					  <div class="header-bottom-left">
  
					  </div>
  
					  <div class="header-bottom-right">
						  <img src="images/header_bottom2.gif" width="540px" />
					  </div>
				  </div>
  
			  </div>
  
			  <div class="maincontent">
				  <div class="sidebar1">
					  <h3> Our Team </h3>
					  Led by a team of leaders from various Fortune 100 companies including AT&T, Sprint, Research in Motion, and Fujitsu and with
					 over 100 employees, Copper Mobile is poised to meet the demands of a rapidly growing industry. Our experienced development
					  team designs and creates applications for all major platforms including iOS, Android, Windows Mobile, and Blackberry.
					 One of Copper Mobile's unique  services includes helping you market your app. Our marketing  team ensures your app is
					 successful by identifying your  target customer base and providing the most effective.
					  <!-- end .sidebar1 -->
  
				  </div>
				  <div class="content">
                  <jdoc:include type="message" />
                  <jdoc:include type="component" />
					  <h3>Our Products</h3>
					  <p>
						  With over 100 hundred apps to our credit since the launch of Apple's iPhone,we understand the uniqueness
						  of each customer's needs and strive to create long-lasting partnerships with our mobile app development clients.
						  When you choose Copper Mobile as your mobile application developer, you get a front row seat to the design,
						  development, and marketing of your mobile app, making sure that it is developed exactly how you envisioned. Our in house
						  team of UI designers, developers, and marketing experts have years of experience deploying and developing mobile apps
						  for iPhone, iPad, Android, Windows Mobile, and Blackberry devices.
					  </p>
				  </div>
				  <div class="sidebar2">
					  <div class="sidebar2_content">
						  <img src="images/sidebar2_bg_title.gif" alt="Suni" style="float:left;margin:0 5px 0 0;" />
						  <p>
							  <h3 style="margin:0;padding:0">Iphone Applications </h3> <br />
							  Do you have the next industry changing iPhone App idea?
							  </span>
						  </p>
					  </div>
					  <div class="sidebar2_content">
						  <img src="images/sidebar2_bg_title2.gif" alt="Suni" style="float:left;margin:0 5px 0 0;" />
						  <p>
							  <h3 style="margin:0;padding:0">Android Applications </h3> <br />
							  Do you have the next industry changing Android App idea?
							  </span>
						  </p>
					  </div>
					  <div class="sidebar2_content">
						  <img src="images/sidebar2_bg_title3.gif" alt="Suni" style="float:left;margin:0 5px 0 0;" />
						  <p>
							  <h3 style="margin:0;padding:0">Windows Applications </h3> <br />
							  Do you have the next industry changing iPhone App idea?
							  </span>
						  </p>
					  </div>
				  </div>
				  <div class="clearfloat">
			  </div>
		  </div>
			  <div class="footer" >
			  
							<div style="float:left;width:25%;background-color:#38383B">
		 
				  <h4> <span style="color:#FFF;padding-left:50px">Popular Products </span></h4>
				  <ul>
					  <li><a href="#">IPhone Development</a></li>
					  <li><a href="#">Android Development</a></li>
					  <li><a href="#">Windows Mobile Development</a></li>
					  <li><a href="#">Blackberry Development</a></li>
					  <li><a href="#">IPod Development</a></li>
				  </ul>
				 
			   </div>
			   <div style="float:left;width:25%;background-color:#38383B">
		 
				  <h4> <span style="color:#FFF;padding-left:50px;"> Our Services </span></h4>
				  <ul>
					  <li><a href="#">Mobile App Design</a></li>
					  <li><a href="#">Mobile App Development</a></li>
					  <li><a href="#">Mobile App Marketing</a></li>
					  <li><a href="#">Blackberry Development</a></li>
					  <li><a href="#">IPod Development</a></li>
				  </ul>
				 
			   </div>
			   <div style="float:left;width:25%;background-color:#38383B">
		 
				  <h4> <span style="color:#FFF;padding-left:50px">Related Links </span></h4>
				  <ul>
					  <li><a href="#">LeaderShip Team</a></li>
					  <li><a href="#">Videos</a></li>
					  <li><a href="#">Careers</a></li>
					  <li><a href="#">Testimonials</a></li>
					  <li><a href="#">Press Kit</a></li>
				  </ul>
				 
			   </div>
				 <div style="float:left;width:25%;background-color:#38383B;padding-top:10px;color:#FFF">
		 
				  <h2 style="color:#8BE828;font-family:Arial, Helvetica, sans-serif, Times, serif;font-weight:bold;">Contact Us</h4>
				  Dallas Office: 972-528-6628 <br />
				  Sunnyvale Office: 408-524-3073<br />
				  Baltimore Office: 800-495-0868<br />
				 
			   </div>            
			   
			  </div>
			  <div class="copyright">
				  Copy right 2011
			  </div>
			  <!-- end .container -->
		  </div>
	  </body>
  
  </html>
