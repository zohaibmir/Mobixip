  <?php defined( '_JEXEC' ) or die( 'Restricted access' );?>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml"   xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
	<head>
        <jdoc:include type="head" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/system.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/general.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/template.css" type="text/css" />
	</head>
	  </head>
  
	  <body>
  
  
		  <div class="container">
  
  
			  <div class="header">
				  <div class="header-top">
					  <div class="sitelogo" >
						<jdoc:include type="modules" name="user4" /> 						 													  
					  </div>
  
					  <div class="menu">
                      
                      <jdoc:include type="modules" name="atomic-topmenu" /> 						 
						  <br style="clear:left"/>
					  </div>
					  <!-- end .Top header -->
				  </div>
  
				  <div class="header-bottom">
				  
					  <!--div class="header-bottom-left">
  
					  </div>
  
					  <div class="header-bottom-right">
						 <jdoc:include type="modules" name="headerslide" />
					  </div-->
                      <jdoc:include type="modules" name="headerslide" />
				  </div>
  
			  </div>
  
			  <div class="maincontent">             
              
                  <?php if($this->countModules('articleheader')) { ?>	              
                      <jdoc:include type="modules" name="articleheader" />
                  <?php } ?>
              
              <div class="sidebar1">
				  <jdoc:include type="modules" name="left" />
              </div>
                  <?php if($this->countModules('right')) { ?>
                  
				  	<div class="content">
                  <?php } else { ?>
                  	<div class="content" style="width:640px;">
                   
                
                  <?php } ?>
                  <jdoc:include type="message" />
                  <jdoc:include type="component" />
					 
				  </div>
				  <jdoc:include type="modules" name="right" />
				  <div class="clearfloat">
			  </div>
		  </div>
			  <div class="footer" id="footer" >
			  
				 <div style="float:left;width:25%;background-color:#38383B">
		 
					  <h4> <span style="color:#FFF;padding-left:50px">Popular Products </span></h4>				
					  <jdoc:include type="modules" name="footermenu1" />
			     </div>
			   <div style="float:left;width:25%;background-color:#38383B">
		 
				  <h4> <span style="color:#FFF;padding-left:50px;"> Our Services </span></h4>
				  	<jdoc:include type="modules" name="footermenu2" />				 
			   </div>
			   <div style="float:left;width:25%;background-color:#38383B">
		 
				  <h4> <span style="color:#FFF;padding-left:50px">Related Links </span></h4>
				  <jdoc:include type="modules" name="footermenu3" />
				 
			   </div>
				 <div style="float:left;width:25%;background-color:#38383B;padding-top:10px;color:#FFF">
		 
				  <h2 class="contactus"> Contact Us</h2>
					<jdoc:include type="modules" name="user3" />
    			   </div>            
			   
			  </div>
			  <div class="copyright">
				  <jdoc:include type="modules" name="copyright" />
			  </div>
			  <!-- end .container -->
		  </div>
	  </body>
  
  </html>
